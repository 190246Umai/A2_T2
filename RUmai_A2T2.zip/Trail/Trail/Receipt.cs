﻿
using System.Windows.Forms;

namespace Trail
{
    public partial class Receipt : Form
    {
        //TAKES IN ALL THE ARGUEMENTS PASSED FROM THE RECIEPT BUTTON AND PRINT EACH IN THE RIGHT LABELS
        public Receipt(string CustomerName, string CustomerSurname, string CtyAddress, string StatAddress, string StAddress, string zip, string DatePaid, string PayMethod, string TotalDT, string TotalEx, string TotalBD, string TA, string QtyOne, string QtyTwo, string QtyThree)
        {
            InitializeComponent();
        //Display each in respective boxes
            name.Text = CustomerName+" "+ CustomerSurname;
            address.Text = StAddress + ", " + zip + ", " + StatAddress + ", " + CtyAddress;
            date.Text = DatePaid;
            PMethod.Text = PayMethod;

            DTQtyPrice.Text = "         " + QtyOne + "                      K200.00" + "               K" + TotalDT+".00";
            EXQtyPrice.Text = "         " + QtyTwo + "                      K5000.00" + "              K" + TotalEx + ".00";
            BDQtyPrice.Text = "         " + QtyThree + "                    K5500.00" + "              K" + TotalBD + ".00";


            DisplayTotal.Text = "Total: K " + TA;


        }

    }
}
