﻿namespace Trail
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.Details = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.fax = new System.Windows.Forms.TextBox();
            this.PhnTwo = new System.Windows.Forms.TextBox();
            this.PhnOne = new System.Windows.Forms.TextBox();
            this.zip = new System.Windows.Forms.TextBox();
            this.StatAddress = new System.Windows.Forms.TextBox();
            this.CtyAddress = new System.Windows.Forms.TextBox();
            this.StAddress = new System.Windows.Forms.TextBox();
            this.SName = new System.Windows.Forms.TextBox();
            this.FName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Reciept = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.DatePaid = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.PayMethod = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PaymentDetails = new System.Windows.Forms.ListBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.reset = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.CALCULATE = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.TA = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.TotalDT = new System.Windows.Forms.TextBox();
            this.TotalBD = new System.Windows.Forms.TextBox();
            this.TotalEx = new System.Windows.Forms.TextBox();
            this.DumpTruckPrice = new System.Windows.Forms.TextBox();
            this.BullDozerPrice = new System.Windows.Forms.TextBox();
            this.ExcavatorPrice = new System.Windows.Forms.TextBox();
            this.QtyOne = new System.Windows.Forms.TextBox();
            this.QtyThree = new System.Windows.Forms.TextBox();
            this.QtyTwo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(364, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(722, 43);
            this.label2.TabIndex = 1;
            this.label2.UseWaitCursor = true;
            // 
            // Details
            // 
            this.Details.CausesValidation = false;
            this.Details.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Details.Location = new System.Drawing.Point(339, 22);
            this.Details.Name = "Details";
            this.Details.Size = new System.Drawing.Size(655, 43);
            this.Details.TabIndex = 2;
            this.Details.Text = "The icode Company is a Heavy Machinery distributorin Mandang. If you looking for " +
    "Machines, to hire simply fill the required infromation. Call us on +675 443 227 " +
    "or vist us at www.icode.dl.png";
            this.Details.UseWaitCursor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.fax);
            this.groupBox1.Controls.Add(this.PhnTwo);
            this.groupBox1.Controls.Add(this.PhnOne);
            this.groupBox1.Controls.Add(this.zip);
            this.groupBox1.Controls.Add(this.StatAddress);
            this.groupBox1.Controls.Add(this.CtyAddress);
            this.groupBox1.Controls.Add(this.StAddress);
            this.groupBox1.Controls.Add(this.SName);
            this.groupBox1.Controls.Add(this.FName);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(45, 117);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(377, 483);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.UseWaitCursor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(23, 437);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 15);
            this.label17.TabIndex = 20;
            this.label17.Text = "Fax";
            this.label17.UseWaitCursor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(198, 383);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(51, 15);
            this.label16.TabIndex = 19;
            this.label16.Text = "Phone 2";
            this.label16.UseWaitCursor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(23, 383);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 15);
            this.label15.TabIndex = 18;
            this.label15.Text = "Phone 1";
            this.label15.UseWaitCursor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(21, 286);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 15);
            this.label14.TabIndex = 17;
            this.label14.Text = "Postal/Zip";
            this.label14.UseWaitCursor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(196, 232);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 15);
            this.label13.TabIndex = 16;
            this.label13.Text = "State";
            this.label13.UseWaitCursor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(21, 227);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 15);
            this.label12.TabIndex = 15;
            this.label12.Text = "City";
            this.label12.UseWaitCursor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(21, 174);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 15);
            this.label11.TabIndex = 14;
            this.label11.Text = "Street Address";
            this.label11.UseWaitCursor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(196, 83);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 13;
            this.label10.Text = "Surname";
            this.label10.UseWaitCursor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(21, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 15);
            this.label9.TabIndex = 12;
            this.label9.Text = "Firstname";
            this.label9.UseWaitCursor = true;
            // 
            // fax
            // 
            this.fax.Location = new System.Drawing.Point(26, 411);
            this.fax.Name = "fax";
            this.fax.Size = new System.Drawing.Size(152, 23);
            this.fax.TabIndex = 11;
            this.fax.UseWaitCursor = true;
            // 
            // PhnTwo
            // 
            this.PhnTwo.Location = new System.Drawing.Point(201, 357);
            this.PhnTwo.Name = "PhnTwo";
            this.PhnTwo.Size = new System.Drawing.Size(139, 23);
            this.PhnTwo.TabIndex = 10;
            this.PhnTwo.UseWaitCursor = true;
            // 
            // PhnOne
            // 
            this.PhnOne.Location = new System.Drawing.Point(26, 357);
            this.PhnOne.Name = "PhnOne";
            this.PhnOne.Size = new System.Drawing.Size(152, 23);
            this.PhnOne.TabIndex = 9;
            this.PhnOne.UseWaitCursor = true;
            // 
            // zip
            // 
            this.zip.Location = new System.Drawing.Point(24, 254);
            this.zip.Name = "zip";
            this.zip.Size = new System.Drawing.Size(152, 23);
            this.zip.TabIndex = 8;
            this.zip.UseWaitCursor = true;
            // 
            // StatAddress
            // 
            this.StatAddress.Location = new System.Drawing.Point(199, 201);
            this.StatAddress.Name = "StatAddress";
            this.StatAddress.Size = new System.Drawing.Size(139, 23);
            this.StatAddress.TabIndex = 7;
            this.StatAddress.UseWaitCursor = true;
            // 
            // CtyAddress
            // 
            this.CtyAddress.Location = new System.Drawing.Point(24, 201);
            this.CtyAddress.Name = "CtyAddress";
            this.CtyAddress.Size = new System.Drawing.Size(152, 23);
            this.CtyAddress.TabIndex = 6;
            this.CtyAddress.UseWaitCursor = true;
            // 
            // StAddress
            // 
            this.StAddress.Location = new System.Drawing.Point(24, 151);
            this.StAddress.Name = "StAddress";
            this.StAddress.Size = new System.Drawing.Size(314, 23);
            this.StAddress.TabIndex = 5;
            this.StAddress.UseWaitCursor = true;
            // 
            // SName
            // 
            this.SName.Location = new System.Drawing.Point(199, 57);
            this.SName.Name = "SName";
            this.SName.Size = new System.Drawing.Size(139, 23);
            this.SName.TabIndex = 4;
            this.SName.UseWaitCursor = true;
            // 
            // FName
            // 
            this.FName.Location = new System.Drawing.Point(24, 57);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(152, 23);
            this.FName.TabIndex = 3;
            this.FName.UseWaitCursor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(23, 329);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 19);
            this.label8.TabIndex = 2;
            this.label8.Text = "Contact";
            this.label8.UseWaitCursor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 19);
            this.label7.TabIndex = 1;
            this.label7.Text = "Address";
            this.label7.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(21, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Name";
            this.label6.UseWaitCursor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "Customer Infromation";
            this.label3.UseWaitCursor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listBox1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.Reciept);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.DatePaid);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.PayMethod);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(449, 80);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(545, 320);
            this.groupBox3.TabIndex = 48;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            this.groupBox3.UseWaitCursor = true;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.listBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 18;
            this.listBox1.Location = new System.Drawing.Point(149, 64);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(138, 22);
            this.listBox1.TabIndex = 70;
            this.listBox1.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(345, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 23);
            this.label1.TabIndex = 69;
            this.label1.Text = "See condition for discounts";
            this.label1.UseWaitCursor = true;
            // 
            // Reciept
            // 
            this.Reciept.BackColor = System.Drawing.Color.Red;
            this.Reciept.ForeColor = System.Drawing.Color.Transparent;
            this.Reciept.Location = new System.Drawing.Point(360, 86);
            this.Reciept.Name = "Reciept";
            this.Reciept.Size = new System.Drawing.Size(141, 36);
            this.Reciept.TabIndex = 68;
            this.Reciept.Text = "PRINT RECEIPT";
            this.Reciept.UseVisualStyleBackColor = false;
            this.Reciept.UseWaitCursor = true;
            this.Reciept.Click += new System.EventHandler(this.Reciept_Click_1);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(44, 102);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 15);
            this.label27.TabIndex = 54;
            this.label27.Text = "Payment Date";
            this.label27.UseWaitCursor = true;
            // 
            // DatePaid
            // 
            this.DatePaid.Location = new System.Drawing.Point(149, 99);
            this.DatePaid.Name = "DatePaid";
            this.DatePaid.Size = new System.Drawing.Size(138, 23);
            this.DatePaid.TabIndex = 53;
            this.DatePaid.UseWaitCursor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(44, 64);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 15);
            this.label26.TabIndex = 52;
            this.label26.Text = "Discount";
            this.label26.UseWaitCursor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(44, 35);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(99, 15);
            this.label25.TabIndex = 50;
            this.label25.Text = "Payment Method";
            this.label25.UseWaitCursor = true;
            // 
            // PayMethod
            // 
            this.PayMethod.Location = new System.Drawing.Point(149, 32);
            this.PayMethod.Name = "PayMethod";
            this.PayMethod.Size = new System.Drawing.Size(138, 23);
            this.PayMethod.TabIndex = 49;
            this.PayMethod.UseWaitCursor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.groupBox2.Controls.Add(this.PaymentDetails);
            this.groupBox2.Controls.Add(this.checkedListBox1);
            this.groupBox2.Location = new System.Drawing.Point(47, 151);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(480, 148);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.UseWaitCursor = true;
            // 
            // PaymentDetails
            // 
            this.PaymentDetails.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentDetails.FormattingEnabled = true;
            this.PaymentDetails.ItemHeight = 16;
            this.PaymentDetails.Location = new System.Drawing.Point(161, 31);
            this.PaymentDetails.Name = "PaymentDetails";
            this.PaymentDetails.Size = new System.Drawing.Size(293, 84);
            this.PaymentDetails.TabIndex = 6;
            this.PaymentDetails.UseWaitCursor = true;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.checkedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox1.Font = new System.Drawing.Font("Microsoft NeoGothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Can Change Credit",
            "Terms Credit",
            "Account  On Hold",
            "Restrict Mailing"});
            this.checkedListBox1.Location = new System.Drawing.Point(10, 31);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(120, 90);
            this.checkedListBox1.TabIndex = 5;
            this.checkedListBox1.UseWaitCursor = true;
            this.checkedListBox1.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox1_ItemCheck);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-3, -2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 26);
            this.label4.TabIndex = 47;
            this.label4.Text = "Payment Infromation";
            this.label4.UseWaitCursor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.reset);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.CALCULATE);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.TA);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.TotalDT);
            this.groupBox4.Controls.Add(this.TotalBD);
            this.groupBox4.Controls.Add(this.TotalEx);
            this.groupBox4.Controls.Add(this.DumpTruckPrice);
            this.groupBox4.Controls.Add(this.BullDozerPrice);
            this.groupBox4.Controls.Add(this.ExcavatorPrice);
            this.groupBox4.Controls.Add(this.QtyOne);
            this.groupBox4.Controls.Add(this.QtyThree);
            this.groupBox4.Controls.Add(this.QtyTwo);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(449, 407);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(545, 193);
            this.groupBox4.TabIndex = 49;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            this.groupBox4.UseWaitCursor = true;
            // 
            // reset
            // 
            this.reset.BackColor = System.Drawing.Color.Red;
            this.reset.ForeColor = System.Drawing.Color.Transparent;
            this.reset.Location = new System.Drawing.Point(407, 159);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(120, 23);
            this.reset.TabIndex = 68;
            this.reset.Text = "RESET";
            this.reset.UseVisualStyleBackColor = false;
            this.reset.UseWaitCursor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(425, 41);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 15);
            this.label20.TabIndex = 67;
            this.label20.Text = "Price/Day*Qty";
            this.label20.UseWaitCursor = true;
            // 
            // CALCULATE
            // 
            this.CALCULATE.BackColor = System.Drawing.Color.Red;
            this.CALCULATE.ForeColor = System.Drawing.Color.Transparent;
            this.CALCULATE.Location = new System.Drawing.Point(272, 160);
            this.CALCULATE.Name = "CALCULATE";
            this.CALCULATE.Size = new System.Drawing.Size(120, 23);
            this.CALCULATE.TabIndex = 65;
            this.CALCULATE.Text = "CALCULATE";
            this.CALCULATE.UseVisualStyleBackColor = false;
            this.CALCULATE.UseWaitCursor = true;
            this.CALCULATE.Click += new System.EventHandler(this.CALCULATE_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(75, 164);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 15);
            this.label24.TabIndex = 64;
            this.label24.Text = "Total (K)";
            this.label24.UseWaitCursor = true;
            // 
            // TA
            // 
            this.TA.BackColor = System.Drawing.SystemColors.ControlDark;
            this.TA.Location = new System.Drawing.Point(134, 160);
            this.TA.Name = "TA";
            this.TA.Size = new System.Drawing.Size(132, 23);
            this.TA.TabIndex = 63;
            this.TA.UseWaitCursor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(36, 122);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 15);
            this.label23.TabIndex = 62;
            this.label23.Text = "Bulldozer";
            this.label23.UseWaitCursor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(34, 91);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 15);
            this.label22.TabIndex = 61;
            this.label22.Text = "Excavator";
            this.label22.UseWaitCursor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(34, 62);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 15);
            this.label21.TabIndex = 60;
            this.label21.Text = "Dump Truck";
            this.label21.UseWaitCursor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(292, 41);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 15);
            this.label19.TabIndex = 59;
            this.label19.Text = "Price/Day";
            this.label19.UseWaitCursor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(147, 41);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 15);
            this.label18.TabIndex = 50;
            this.label18.Text = "Quantity";
            this.label18.UseWaitCursor = true;
            // 
            // TotalDT
            // 
            this.TotalDT.Location = new System.Drawing.Point(398, 59);
            this.TotalDT.Name = "TotalDT";
            this.TotalDT.Size = new System.Drawing.Size(139, 23);
            this.TotalDT.TabIndex = 58;
            this.TotalDT.Text = "K";
            this.TotalDT.UseWaitCursor = true;
            // 
            // TotalBD
            // 
            this.TotalBD.Location = new System.Drawing.Point(398, 117);
            this.TotalBD.Name = "TotalBD";
            this.TotalBD.Size = new System.Drawing.Size(139, 23);
            this.TotalBD.TabIndex = 57;
            this.TotalBD.Text = "K";
            this.TotalBD.UseWaitCursor = true;
            // 
            // TotalEx
            // 
            this.TotalEx.Location = new System.Drawing.Point(398, 88);
            this.TotalEx.Name = "TotalEx";
            this.TotalEx.Size = new System.Drawing.Size(139, 23);
            this.TotalEx.TabIndex = 56;
            this.TotalEx.Text = "K";
            this.TotalEx.UseWaitCursor = true;
            // 
            // DumpTruckPrice
            // 
            this.DumpTruckPrice.Location = new System.Drawing.Point(253, 59);
            this.DumpTruckPrice.Name = "DumpTruckPrice";
            this.DumpTruckPrice.Size = new System.Drawing.Size(139, 23);
            this.DumpTruckPrice.TabIndex = 55;
            this.DumpTruckPrice.UseWaitCursor = true;
            // 
            // BullDozerPrice
            // 
            this.BullDozerPrice.Location = new System.Drawing.Point(253, 117);
            this.BullDozerPrice.Name = "BullDozerPrice";
            this.BullDozerPrice.Size = new System.Drawing.Size(139, 23);
            this.BullDozerPrice.TabIndex = 54;
            this.BullDozerPrice.UseWaitCursor = true;
            // 
            // ExcavatorPrice
            // 
            this.ExcavatorPrice.Location = new System.Drawing.Point(253, 88);
            this.ExcavatorPrice.Name = "ExcavatorPrice";
            this.ExcavatorPrice.Size = new System.Drawing.Size(139, 23);
            this.ExcavatorPrice.TabIndex = 53;
            this.ExcavatorPrice.UseWaitCursor = true;
            // 
            // QtyOne
            // 
            this.QtyOne.Location = new System.Drawing.Point(108, 59);
            this.QtyOne.Name = "QtyOne";
            this.QtyOne.Size = new System.Drawing.Size(139, 23);
            this.QtyOne.TabIndex = 52;
            this.QtyOne.UseWaitCursor = true;
            this.QtyOne.TextChanged += new System.EventHandler(this.QtyOne_TextChanged);
            // 
            // QtyThree
            // 
            this.QtyThree.Location = new System.Drawing.Point(108, 117);
            this.QtyThree.Name = "QtyThree";
            this.QtyThree.Size = new System.Drawing.Size(139, 23);
            this.QtyThree.TabIndex = 51;
            this.QtyThree.UseWaitCursor = true;
            this.QtyThree.TextChanged += new System.EventHandler(this.QtyThree_TextChanged);
            // 
            // QtyTwo
            // 
            this.QtyTwo.Location = new System.Drawing.Point(108, 88);
            this.QtyTwo.Name = "QtyTwo";
            this.QtyTwo.Size = new System.Drawing.Size(139, 23);
            this.QtyTwo.TabIndex = 49;
            this.QtyTwo.UseWaitCursor = true;
            this.QtyTwo.TextChanged += new System.EventHandler(this.QtyTwo_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, -2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 26);
            this.label5.TabIndex = 48;
            this.label5.Text = "Hire Infromation";
            this.label5.UseWaitCursor = true;
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(56, 20);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(277, 43);
            this.label28.TabIndex = 50;
            this.label28.Text = "i";
            this.label28.UseWaitCursor = true;
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(23, 18);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(277, 43);
            this.label29.TabIndex = 50;
            this.label29.Text = "i";
            this.label29.UseWaitCursor = true;
            // 
            // label30
            // 
            this.label30.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(39, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(261, 43);
            this.label30.TabIndex = 51;
            this.label30.Text = "Code Companies";
            this.label30.UseWaitCursor = true;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1021, 619);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Details);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Location = new System.Drawing.Point(200, 500);
            this.Name = "Calculator";
            this.Text = "iCode Companies";
            this.UseWaitCursor = true;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Details;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox fax;
        private System.Windows.Forms.TextBox PhnTwo;
        private System.Windows.Forms.TextBox PhnOne;
        private System.Windows.Forms.TextBox zip;
        private System.Windows.Forms.TextBox StatAddress;
        private System.Windows.Forms.TextBox CtyAddress;
        private System.Windows.Forms.TextBox StAddress;
        private System.Windows.Forms.TextBox SName;
        private System.Windows.Forms.TextBox FName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox DatePaid;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox PayMethod;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button CALCULATE;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox TA;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TotalDT;
        private System.Windows.Forms.TextBox TotalBD;
        private System.Windows.Forms.TextBox TotalEx;
        private System.Windows.Forms.TextBox DumpTruckPrice;
        private System.Windows.Forms.TextBox BullDozerPrice;
        private System.Windows.Forms.TextBox ExcavatorPrice;
        private System.Windows.Forms.TextBox QtyOne;
        private System.Windows.Forms.TextBox QtyThree;
        private System.Windows.Forms.TextBox QtyTwo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button Reciept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.ListBox PaymentDetails;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button reset;
    }
}

