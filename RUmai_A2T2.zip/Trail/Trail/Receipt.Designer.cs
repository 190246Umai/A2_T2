﻿namespace Trail
{
    partial class Receipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Receipt));
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PMethod = new System.Windows.Forms.Label();
            this.date = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.DisplayTotal = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.DTQtyPrice = new System.Windows.Forms.Label();
            this.EXQtyPrice = new System.Windows.Forms.Label();
            this.BDQtyPrice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.Name = "label30";
            this.label30.UseWaitCursor = true;
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.Name = "label29";
            this.label29.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // PMethod
            // 
            this.PMethod.BackColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.PMethod, "PMethod");
            this.PMethod.Name = "PMethod";
            // 
            // date
            // 
            this.date.BackColor = System.Drawing.SystemColors.ActiveBorder;
            resources.ApplyResources(this.date, "date");
            this.date.Name = "date";
            // 
            // address
            // 
            this.address.BackColor = System.Drawing.SystemColors.ActiveBorder;
            resources.ApplyResources(this.address, "address");
            this.address.Name = "address";
            // 
            // name
            // 
            this.name.BackColor = System.Drawing.SystemColors.ActiveBorder;
            resources.ApplyResources(this.name, "name");
            this.name.Name = "name";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // DisplayTotal
            // 
            this.DisplayTotal.BackColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.DisplayTotal, "DisplayTotal");
            this.DisplayTotal.Name = "DisplayTotal";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Name = "label12";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            this.label23.UseWaitCursor = true;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            this.label22.UseWaitCursor = true;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            this.label21.UseWaitCursor = true;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            this.label16.UseWaitCursor = true;
            // 
            // DTQtyPrice
            // 
            this.DTQtyPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.DTQtyPrice, "DTQtyPrice");
            this.DTQtyPrice.Name = "DTQtyPrice";
            // 
            // EXQtyPrice
            // 
            this.EXQtyPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.EXQtyPrice, "EXQtyPrice");
            this.EXQtyPrice.Name = "EXQtyPrice";
            // 
            // BDQtyPrice
            // 
            this.BDQtyPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.BDQtyPrice, "BDQtyPrice");
            this.BDQtyPrice.Name = "BDQtyPrice";
            // 
            // Receipt
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.BDQtyPrice);
            this.Controls.Add(this.EXQtyPrice);
            this.Controls.Add(this.DTQtyPrice);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.DisplayTotal);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.PMethod);
            this.Controls.Add(this.date);
            this.Controls.Add(this.address);
            this.Controls.Add(this.name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Receipt";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label PMethod;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label DisplayTotal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label DTQtyPrice;
        private System.Windows.Forms.Label EXQtyPrice;
        private System.Windows.Forms.Label BDQtyPrice;
    }
}